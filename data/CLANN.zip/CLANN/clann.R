clann <- function(physio, meteo, fossil, 
				  spread=c(0.52,0.55,0.49,0.56,0.57,0.58,0.56,0.52,0.49,0.56,0.55)){
	require(fields)
	if(all(!spread)) spread <- findSpread(physio, meteo, k=10)
	predict <- matrix(ncol=ncol(meteo), nrow=nrow(fossil))
	minp <- apply(physio,2,min)
	maxp <- apply(physio,2,max)
	norm_phys <- t(2*(t(physio)-minp)/(maxp-minp)-1)
	for (m in 1:nrow(fossil)){
		pred_it <- numeric(ncol(meteo))
  		norm_f <- t(2*(t(fossil[m,])-minp)/(maxp-minp)-1)
  		weights <- rdist(norm_phys,norm_f)
  		for (k in 1:ncol(meteo)){
    		b.input <- weights*0.8326/spread[k]
    		a1 <- exp(-b.input^2)
    		weight_all <- sum(a1)
    		if(weight_all==0) weight_all <- 1
    		pred_it[k] <- crossprod(a1,as.matrix(meteo[,k]))/weight_all
  		}
  		predict[m,] <- pred_it
	}
	colnames(predict) <- colnames(meteo)
	rownames(predict) <- rownames(fossil)
	predict
}
