findSpread <- function(x,y,k=10,r=200){
	require(fields)
	require(cvTools)
	nr <- nrow(x)
	cvr <- cvFolds(nr, K = k)
	subcvr <- cvr$subsets
	nm <- ncol(y)
	rsquare_all <- matrix(nrow=r,ncol=nm)
	for(s in 1:r){
		predict <- matrix(nrow=nr,ncol=nm)
		spread <- s/100
		for(i in 1:k){      
			train.physg <- x[subcvr[cvr$which != i], ]
			validation.physg <- x[subcvr[cvr$which == i], ]
			train.met <- y[subcvr[cvr$which != i], ]
			validation.met <- y[subcvr[cvr$which == i], ]
			minp <- apply(train.physg,2,min)
			maxp <- apply(train.physg,2,max)
			train.physg <- t(2*(t(train.physg)-minp)/(maxp-minp)-1)
			corr_validation.physg <- t(2*(t(validation.physg)-minp)/(maxp-minp)-1)
			w.input <- rdist(train.physg,corr_validation.physg)
			b.input <- w.input*0.8326/spread
			a1 <- exp(-b.input^2)
			weight_all <- colSums(a1)
			for(h in 1:ncol(a1)){if(weight_all[h]==0){weight_all[h]<-1}}
			pred_it <- (t(a1) %*% as.matrix(train.met))/weight_all
			row.names(pred_it) <- row.names(validation.met)
			predict[subcvr[cvr$which == i],] <- pred_it
		}     
      res <- predict - y
      stdev <- numeric(nm)
      rsquare <- numeric(nm)
      for(n in 1:ncol(res)){    
      		if(all(predict[,n] == 0)){predict[1,n]=0.01}
       		stdev[n] <- sd(res[,n])
       		rsquare[n] <- cor(y[,n],predict[,n])^2
       }
      rsquare_all[s,] <- rsquare
    }
    best.spread <- numeric(nm)
    test <- cbind((1:r)/100,rsquare_all)
    for(nn in 1:nm) best.spread[nn] <- test[which.max(test[,nn+1]),1]
    best.spread
}
