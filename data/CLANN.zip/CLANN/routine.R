load("clamp calibrations.Rdata")
source("findSpread.R")
source("clann.R")
library(gdata)
set.seed(2020)
baris = read.xls("Scoresheet_Baris.xlsx",sheet="Result",skip=3,check.names=FALSE)
fossil = baris[baris[,2]=="Percentage Score",3+1:31]
clann(physio,meteo,fossil,spread=FALSE)
