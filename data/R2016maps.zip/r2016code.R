library(gdata)
library(reshape)
library(fields)
library(maptools)
library(sp)
library(rgdal)
renaudie2016supmat <- "https://www.biogeosciences.net/13/6003/2016/bg-13-6003-2016-supplement.zip"
download.file(renaudie2016supmat,"supmat.zip")
unzip("supmat.zip")
file <- "Supplementary Files/Renaudie - Quantifying the Cenozoic marine diatom deposition history - Supplementary File 1.xls"
data <- read.xls(file,sheet=1)
sm_data <- data[!is.na(data$Diatoms),]
breaks <- c(-1e8,seq(20,80,by=20),1e8)
col <- colorRampPalette(c("#ffffcc","#c2e699","#78c679","#31a354","#006837"))(length(breaks)-1)
gridlon <- seq(-180,180,1)
gridlat <- seq(-90,90,1)
LAG_STEP <- 100
agebin<-c(0,2.588,3.6,5.333,11.62,15.97,23.03,28.1,33.9,38,47.8,56,61.6)
age <- c(0,3,5,8,13,20,25,31,36,43,52,59)
stage <- c("Late Paleocene","Early Eocene","Middle Eocene","Late Eocene", "Early Oligocene", "Late Oligocene", "Early Miocene","Middle Miocene", "Late Miocene", "Early Pliocene", "Late Pliocene", "Pleistocene")

val2col<-function(z, zlim, col = heat.colors(12), breaks){ 
  #Courtesy of http://menugget.blogspot.com/2011/09/converting-values-to-color-levels.html
  if(!missing(breaks)){
    if(length(breaks) != (length(col)+1)){stop("must have one more break than colour")}
  }
  if(missing(breaks) & !missing(zlim)){
    zlim[2] <- zlim[2]+c(zlim[2]-zlim[1])*(1E-3)
    zlim[1] <- zlim[1]-c(zlim[2]-zlim[1])*(1E-3)
    breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1)) 
  }
  if(missing(breaks) & missing(zlim)){
    zlim <- range(z, na.rm=TRUE)
    zlim[2] <- zlim[2]+c(zlim[2]-zlim[1])*(1E-3)
    zlim[1] <- zlim[1]-c(zlim[2]-zlim[1])*(1E-3)
    breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1))
  }
  CUT <- cut(z, breaks=breaks)
  colorlevels <- col[match(CUT, levels(CUT))]
  return(colorlevels)
}

grd.res <- diff(gridlon)[1]
tmp <- list(lon=gridlon, lat=gridlat)
grd <- make.surface.grid(tmp)
polys <- vector(mode="list", nrow(grd))
for(j in seq(polys)){
  xci <- grd[j,1]
  yci <- grd[j,2]
  xs <- c(xci-grd.res/2, xci-grd.res/2, xci+grd.res/2, xci+grd.res/2)
  ys <- c(yci-grd.res/2, yci+grd.res/2, yci+grd.res/2, yci-grd.res/2)
  polys[[j]]$x <- xs
  polys[[j]]$y <- ys
}

map_list <- list()

for(i in 1:12){
  cat(stage[13-i], ": Sorting the data\n")
  agemin <- agebin[i]
  agemax <- agebin[i+1]
  odp_at_z <- readOGR(dsn=paste0(getwd(),"/odp"),layer=sprintf("reconstructed_%i.00Ma", age[i]), verbose=FALSE)
  dsdp_at_z <- readOGR(dsn=paste0(getwd(),"/dsdpsites"),layer=sprintf("reconstructed_%i.00Ma", age[i]), verbose=FALSE)
  a <- c(as.character(odp_at_z@data$Site),sapply(strsplit(as.character(dsdp_at_z@data$SITELABEL),"-"),`[`,2))
  Coords <- rbind(odp_at_z@coords,dsdp_at_z@coords)
  Lon<-Lat<-c()
  sm_data<-sm_data[gsub("[A-Z]","",sm_data$Site)%in%a,]
  for(j in 1:nrow(sm_data)){
    Lon[j]<-Coords[a==gsub("[A-Z]","",sm_data$Site[j]),1][1]
    Lat[j]<-Coords[a==gsub("[A-Z]","",sm_data$Site[j]),2][1]
  }
  Longlat<-cbind(Lon,Lat)
  agegrid <- sm_data[sm_data[,3]>=agemin & sm_data[,3]<=agemax,]
  agegrid2 <- Longlat[sm_data[,3]>=agemin & sm_data[,3]<=agemax,]
  B <- data.frame(Site=agegrid$Site, Value=agegrid$Diatoms, Lon=agegrid2[,1], Lat=agegrid2[,2], stringsAsFactors=FALSE)
  M <- rdist.earth(cbind(B$Lon,B$Lat),cbind(B$Lon,B$Lat),miles=FALSE) #Great Circle distance
  colnames(M)<-rownames(M)<-B$Site
  N <- melt(M)
  colnames(N) <- c("X", "Y", "Dist")
  P <- outer(B$Value,B$Value,`-`)
  colnames(P)<-rownames(P)<-B$Site
  Q <- melt(P)
  N$Diff <- abs(Q[,3])
  N$HCat <- cut(N$Dist,c(-1,seq(0,21000,by=LAG_STEP)), right=TRUE) #Makes space-bins (2e4 is largest possible distance on earth)
  levels(N$HCat) <- sapply(split(N$Dist,N$HCat),mean) #Mean value of each space-bins
  N$H <- as.numeric(as.character(N$HCat))
  N$H[is.na(N$H)]<-0
  V <- sapply(split(N,N$H),function(x)sum(x$Diff^2)/(2*nrow(x))) #Semivariance
  H <- as.double(names(V)) #Associated lags
  pdf(sprintf("%s - variogram.pdf",stage[13-i]))
  plot(H,V,xlim=c(0,20040),ylim=c(0,max(V)),yaxs="i",xaxs="i",xlab="Lag (in km)", ylab="Semivariance", main="Variogram",pch=19)
  abline(h=var(B$Value),lty=3)
  mtext(round(V[1],2),side=2,at=V[1],las=2,cex=0.6,line=0.5)
  mtext(round(var(B$Value),2),side=2,at=var(B$Value),las=2,cex=0.6,line=0.5,font=3)
  f = function(x,H,V){sum(abs((x[1] + (x[2]-x[1])*(1-exp(-3*H[-1]/x[3])))-V[-1]))}
  p = optim(c(0,var(B$Value),5000),f,H=H[H<5000],V=V[H<5000])$par
  Sill = p[2]
  Nugget = p[1]
  Range = p[3]
  
  gamma = function(h){Nugget + (Sill-Nugget)*(1-exp(-3*h/Range))}
  curve(gamma(x), from=0, to=20000, col="red", lwd=2, add=TRUE)
  dev.off()
  
  gamma_all = structure(sapply(M, gamma), dim=dim(M))
  gamma_all = rbind(cbind(gamma_all,1),1)
  gamma_all[nrow(gamma_all),ncol(gamma_all)] = 0
  Ig <- MASS::ginv(gamma_all)
  
  interpo = function(X0,Y0){
    h_star = fields::rdist.earth(cbind(B$Lon,B$Lat),cbind(X0,Y0),miles=FALSE)
    gamma_star = sapply(h_star,gamma)
    gamma_star = c(gamma_star,1)
    W = Ig%*%gamma_star
    lagrange = W[length(W)]
    W = W[-length(W)]
    sum(B$Value*W)
  }
  cat(stage[13-i], ": Kriging\n")
  grd = expand.grid(gridlon,gridlat)
  new_grd <- rep(NA,nrow(grd))
  for(j in 1:nrow(grd)){
    new_grd[j] <- interpo(grd[j,1],grd[j,2])
    cat(stage[13-i], ":", j,"/",nrow(grd),"\r")
  }
  cat("\n")
  map_list[[i]] <- list(N=N, VH=cbind(V,H), Function=data.frame(Nugget, Sill, Range), Krige=new_grd, Datapoints=cbind(agegrid2,agegrid))
  save(map_list,file="map_list.Rdata")
}

cat("Plotting...\n")
for(i in 1:12){
  COL <- val2col(map_list[[i]]$Krige, col=col, breaks=breaks)
  pdf(sprintf("%s - Krige.pdf",stage[13-i]), h=4, w=8)
  par(mar=c(0,0,0,0))
  plot(0,0, xaxs="i", yaxs="i", xlim=c(-180,180),ylim=c(-90,90), bty="n", type="n")
  for(j in 1:length(polys)){
    polygon(polys[[j]], col=COL[j], border=COL[j])
  }
  Land <- readShapeSpatial(sprintf("CoastLines/reconstructed_%i.00Ma.shp",age[i]))
  plot(Land, add=TRUE, col="white")
  pts <- unique(map_list[[i]]$Datapoints[,c("Lon","Lat")])
  points(pts,pch=21, bg="black", col="white", cex=.6)
  dev.off()
}
