cd "$( dirname "${BASH_SOURCE[0]}")"
xelatex template
xelatex template
